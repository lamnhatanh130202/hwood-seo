# -*- coding: utf-8 -*-
"""
HWOOD - HỆ THỐNG 5 BOT QUÉT THỨ HẠNG GOOGLE ĐỘC LẬP (PROXY/VPN RIÊNG)
=====================================================================
Mỗi bot chạy trên 1 luồng (thread) độc lập, dùng 1 địa chỉ proxy/VPN riêng,
trình duyệt thật (Chromium) có chống phát hiện. 5 bot chia sẻ chung 1 hàng đợi
từ khóa đã xáo trộn ngẫu nhiên, lấy từ khóa đến khi hết. Với mỗi từ khóa:
  1. Mở Google, gõ từ khóa như người thật (trễ ngẫu nhiên giữa các phím).
  2. Quét trang 1 -> trang 5 (tối đa 50 kết quả organic), tìm URL chứa hwood.vn,
     ghi nhận vị trí + tiêu đề.
  3. Nếu thấy bài/sản phẩm hwood.vn: click vào kết quả cao nhất, cuộn trang đọc
     nội dung, ở lại một khoảng thời gian ngẫu nhiên (mặc định 45-90s) rồi quay lại.
  4. Nếu không thấy đến trang 5: đánh dấu "Ngoài Top 50", bỏ qua, tiếp tục từ khóa sau.
  5. Ghi kết quả ra file JSON/CSV ngay lập tức (không mất dữ liệu khi dừng giữa chừng).

LƯU Ý QUAN TRỌNG (đọc trước khi chạy):
  - Hành vi click + ở lại trang (dwell time) ở quy mô bot có thể bị Google xem là
    thao túng CTR và gây rủi ro phạt website. Công cụ này được xây dựng CHÍNH để
    KIỂM TRA THỨ HẠNG và XÁC MINH NỘI DUNG trang. Hãy dùng ở mức độ vừa phải,
    ưu tiên proxy residential (IP nhà dân) để tránh bị chặn.
  - Cần cài: pip install playwright  ->  playwright install chromium
  - Tùy chọn chống phát hiện tốt hơn: pip install playwright-stealth
"""
import os
import re
import json
import time
import random
import queue
import threading
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

# Thư mục gốc dự án (chứa app.py) - file này nằm trong modules/
CURRENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_FILE = os.path.join(CURRENT_DIR, "lich_su_bot_farm.json")
PROGRESS_FILE = os.path.join(CURRENT_DIR, "bot_farm_progress.json")
PROXY_CONFIG_FILE = os.path.join(CURRENT_DIR, "bot_proxies.json")

# Miền mục tiêu cần tìm trong kết quả Google
TARGET_DOMAIN = "hwood.vn"

# Pool User-Agent thật (Chrome trên Windows) - mỗi bot chọn ngẫu nhiên 1 cái
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
]

# Kích thước màn hình phổ biến (mỗi bot dùng 1 viewport riêng)
VIEWPORTS = [
    {"width": 1920, "height": 1080},
    {"width": 1366, "height": 768},
    {"width": 1536, "height": 864},
    {"width": 1440, "height": 900},
    {"width": 1280, "height": 720},
]

# Thử import playwright-stealth (chống phát hiện tốt hơn) - nếu không có thì bỏ qua
try:
    from playwright_stealth import stealth_sync
    HAS_STEALTH = True
except ImportError:
    HAS_STEALTH = False


# ==============================================================================
# 1. CẤU HÌNH MỖI BOT
# ==============================================================================
@dataclass
class BotConfig:
    bot_id: str
    name: str
    proxy_server: str = ""          # ví dụ: http://1.2.3.4:8080  hoặc socks5://...
    proxy_username: str = ""
    proxy_password: str = ""
    user_agent: str = field(default_factory=lambda: random.choice(USER_AGENTS))
    viewport: Dict = field(default_factory=lambda: random.choice(VIEWPORTS))

    def proxy_dict(self) -> Optional[Dict]:
        if not self.proxy_server:
            return None
        p = {"server": self.proxy_server}
        if self.proxy_username:
            p["username"] = self.proxy_username
            p["password"] = self.proxy_password
        return p


# ==============================================================================
# 2. HÀM TIỆN ÍCH - HÀNH VI NGƯỜI THẬT
# ==============================================================================
def human_sleep(min_s: float = 2.0, max_s: float = 5.0):
    """Ngủ một khoảng ngẫu nhiên để mô phỏng tốc độ đọc/nhìn của người thật."""
    time.sleep(random.uniform(min_s, max_s))


def random_scroll(page, min_scrolls: int = 3, max_scrolls: int = 8):
    """Cuộn trang từng đoạn với tốc độ ngẫu nhiên, giống người đọc nội dung."""
    for _ in range(random.randint(min_scrolls, max_scrolls)):
        delta = random.randint(200, 600)
        page.mouse.wheel(0, delta)
        human_sleep(0.5, 1.8)


def type_like_human(page, selector: str, text: str):
    """Gõ từng ký tự với độ trễ ngẫu nhiên, không dán nguyên khối."""
    page.click(selector)
    human_sleep(0.3, 0.8)
    for ch in text:
        page.keyboard.type(ch, delay=random.randint(40, 140))
    human_sleep(0.4, 1.0)
    page.keyboard.press("Enter")


def doc_proxy_config() -> List[BotConfig]:
    """Đọc cấu hình 5 proxy từ file bot_proxies.json (nếu có)."""
    if not os.path.exists(PROXY_CONFIG_FILE):
        return [BotConfig(bot_id=f"bot_{i+1:02d}", name=f"Bot {i+1}") for i in range(5)]
    try:
        with open(PROXY_CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        bots = []
        for i, item in enumerate(data.get("bots", [])):
            bots.append(BotConfig(
                bot_id=item.get("bot_id", f"bot_{i+1:02d}"),
                name=item.get("name", f"Bot {i+1}"),
                proxy_server=item.get("proxy_server", ""),
                proxy_username=item.get("proxy_username", ""),
                proxy_password=item.get("proxy_password", ""),
            ))
        return bots
    except Exception:
        return [BotConfig(bot_id=f"bot_{i+1:02d}", name=f"Bot {i+1}") for i in range(5)]


# ==============================================================================
# 3. KẾT QUẢ - AN TOÀN ĐA LUỒNG
# ==============================================================================
class ResultStore:
    def __init__(self):
        self.lock = threading.Lock()
        self.results: List[Dict] = []
        self._load()

    def _load(self):
        if os.path.exists(RESULTS_FILE):
            try:
                with open(RESULTS_FILE, "r", encoding="utf-8") as f:
                    self.results = json.load(f)
            except Exception:
                self.results = []

    def add(self, record: Dict):
        with self.lock:
            self.results.append(record)
            with open(RESULTS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.results, f, ensure_ascii=False, indent=2)

    def all(self) -> List[Dict]:
        with self.lock:
            return list(self.results)


# ==============================================================================
# 4. LUỒNG CÔNG VIỆC CỦA MỘT BOT
# ==============================================================================
class BotWorker(threading.Thread):
    def __init__(
        self,
        config: BotConfig,
        keyword_queue: queue.Queue,
        result_store: ResultStore,
        max_pages: int = 5,
        dwell_min: int = 45,
        dwell_max: int = 90,
        visit_pages: bool = True,
        headless: bool = True,
        stop_event: Optional[threading.Event] = None,
    ):
        super().__init__(daemon=True)
        self.config = config
        self.keyword_queue = keyword_queue
        self.result_store = result_store
        self.max_pages = max_pages
        self.dwell_min = dwell_min
        self.dwell_max = dwell_max
        self.visit_pages = visit_pages
        self.headless = headless
        self.stop_event = stop_event or threading.Event()
        self.processed = 0
        self.found_count = 0
        self.errors = []

    def _log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] {self.config.name}: {msg}", flush=True)

    def _write_progress(self, status: str, detail: str = ""):
        """Ghi tiến độ hiện tại ra file để giao diện Streamlit đọc được."""
        try:
            prog = {}
            if os.path.exists(PROGRESS_FILE):
                with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
                    prog = json.load(f)
            prog[self.config.bot_id] = {
                "name": self.config.name,
                "status": status,
                "detail": detail,
                "processed": self.processed,
                "found": self.found_count,
                "updated_at": datetime.now().isoformat(),
            }
            with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
                json.dump(prog, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _extract_serp_results(self, page) -> List[Dict]:
        """Trích xuất danh sách kết quả organic (vị trí, tiêu đề, URL) từ DOM Google."""
        js = """
        () => {
            const results = [];
            // Google hiển thị tiêu đề trong thẻ <h3>; link là thẻ <a> cha gần nhất
            const h3s = document.querySelectorAll('h3');
            let pos = 0;
            h3s.forEach(h3 => {
                let a = h3.closest('a');
                if (!a) return;
                const href = a.href || '';
                if (!href.startsWith('http')) return;
                if (href.includes('google.')) return;
                pos += 1;
                results.push({
                    position: pos,
                    title: h3.innerText || '',
                    url: href.split('?')[0].split('#')[0].replace(/\\/$/, '')
                });
            });
            return results;
        }
        """
        try:
            return page.evaluate(js)
        except Exception:
            return []

    def _find_hwood_results(self, serp: List[Dict]) -> List[Dict]:
        return [r for r in serp if TARGET_DOMAIN in r.get("url", "").lower()]

    def _is_blocked(self, page) -> bool:
        try:
            content = page.content().lower()
            return ("captcha" in content) or ("unusual traffic" in content) or ("sorry/index" in page.url)
        except Exception:
            return False

    def _accept_consent_if_needed(self, page):
        """Nhấn nút đồng ý cookie/điều khoản nếu Google hiện lên."""
        for btn_text in ["Tôi đồng ý", "Đồng ý", "Accept all", "Accept", "Tôi chấp nhận"]:
            try:
                btn = page.get_by_role("button", name=re.compile(btn_text, re.IGNORECASE))
                if btn.count() > 0:
                    btn.first.click(timeout=2000)
                    human_sleep(1, 2)
                    return
            except Exception:
                continue

    def _visit_hwood_page(self, page, result: Dict):
        """Click vào kết quả hwood.vn, cuộn đọc nội dung, ở lại một khoảng ngẫu nhiên."""
        self._log(f"👉 Vào trang: {result['url'][:70]} (Top {result['position']})")
        try:
            # Click vào link kết quả (mở trong cùng tab)
            page.get_by_role("link", name=re.compile(re.escape(result["title"][:30]), re.IGNORECASE)).first.click(timeout=8000)
        except Exception:
            # Fallback: điều hướng thẳng tới URL
            page.goto(result["url"], timeout=30000)
        try:
            page.wait_for_load_state("domcontentloaded", timeout=15000)
        except Exception:
            pass
        human_sleep(2, 4)
        # Cuộn đọc nội dung như người thật
        random_scroll(page, min_scrolls=4, max_scrolls=10)
        # Ở lại trang (dwell) trong khoảng dwell_min -> dwell_max giây, có cuộn xen kẽ
        dwell = random.randint(self.dwell_min, self.dwell_max)
        self._log(f"⏳ Đọc nội dung ~{dwell}s...")
        elapsed = 0
        while elapsed < dwell:
            chunk = random.randint(5, 15)
            time.sleep(chunk)
            elapsed += chunk
            if random.random() < 0.5:
                page.mouse.wheel(0, random.randint(150, 500))
        # Quay lại trang kết quả Google
        try:
            page.go_back(timeout=10000)
            human_sleep(1.5, 3)
        except Exception:
            pass

    def run(self):
        from playwright.sync_api import sync_playwright
        self._write_progress("starting", "Khởi động trình duyệt")
        try:
            with sync_playwright() as p:
                proxy = self.config.proxy_dict()
                browser = p.chromium.launch(
                    headless=self.headless,
                    proxy=proxy,
                    args=[
                        "--disable-blink-features=AutomationControlled",
                        "--disable-dev-shm-usage",
                        "--no-sandbox",
                        "--start-maximized",
                    ],
                )
                context = browser.new_context(
                    user_agent=self.config.user_agent,
                    viewport=self.config.viewport,
                    locale="vi-VN",
                    timezone_id="Asia/Ho_Chi_Minh",
                    proxy=proxy,
                )
                if HAS_STEALTH:
                    stealth_sync(context)
                page = context.new_page()
                # Xóa thuộc tính navigator.webdriver (chống phát hiện cơ bản)
                page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

                self._write_progress("running", "Sẵn sàng, lấy từ khóa...")

                while not self.stop_event.is_set():
                    try:
                        keyword = self.keyword_queue.get_nowait()
                    except queue.Empty:
                        break

                    self.processed += 1
                    self._log(f"🔍 Tra từ khóa [{self.processed}]: {keyword}")
                    self._write_progress("running", f"Đang tra: {keyword}")

                    record = {
                        "tu_khoa": keyword,
                        "bot_id": self.config.bot_id,
                        "bot_name": self.config.name,
                        "thoi_gian": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                        "ket_qua_hwood": [],
                        "trang_thai": "ok",
                    }

                    try:
                        # Bước 1: Mở Google Việt Nam
                        page.goto("https://www.google.com.vn?hl=vi&gl=vn", timeout=30000)
                        human_sleep(1.5, 3)
                        self._accept_consent_if_needed(page)

                        # Bước 2: Gõ từ khóa như người thật
                        try:
                            type_like_human(page, "textarea[name='q']", keyword)
                        except Exception:
                            page.goto(
                                f"https://www.google.com.vn/search?q={keyword}&hl=vi&gl=vn",
                                timeout=30000,
                            )
                        human_sleep(2.5, 5)

                        if self._is_blocked(page):
                            record["trang_thai"] = "bi_chan_captcha"
                            self.errors.append(f"Captcha tại '{keyword}'")
                            self.result_store.add(record)
                            self._log("⛔ Bị Google chặn (captcha) - dừng bot này")
                            self._write_progress("blocked", "Bị captcha, cần đổi proxy")
                            break

                        # Bước 3: Quét trang 1 -> trang N
                        all_hwood = []
                        for page_num in range(1, self.max_pages + 1):
                            serp = self._extract_serp_results(page)
                            hwood_hits = self._find_hwood_results(serp)
                            for h in hwood_hits:
                                h["trang_google"] = page_num
                            all_hwood.extend(hwood_hits)
                            if hwood_hits:
                                self._log(f"   ✅ Trang {page_num}: thấy {len(hwood_hits)} kết quả hwood.vn")
                            # Chuyển trang tiếp theo (nếu chưa phải trang cuối)
                            if page_num < self.max_pages:
                                try:
                                    next_btn = page.locator("#pnnext, a#pnnext")
                                    if next_btn.count() > 0:
                                        human_sleep(2, 4)
                                        next_btn.first.click(timeout=5000)
                                        human_sleep(2.5, 5)
                                    else:
                                        break
                                except Exception:
                                    break

                        record["ket_qua_hwood"] = all_hwood
                        if all_hwood:
                            self.found_count += len(all_hwood)
                            # Vào trang hwood cao nhất để đọc nội dung
                            if self.visit_pages:
                                top_hit = min(all_hwood, key=lambda x: x["position"])
                                self._visit_hwood_page(page, top_hit)
                        else:
                            record["trang_thai"] = "ngoai_top_50"
                            self._log("   ⚪ Không thấy hwood.vn trong Top 50 - bỏ qua")

                    except Exception as e:
                        record["trang_thai"] = "loi"
                        record["loi"] = str(e)[:200]
                        self.errors.append(f"{keyword}: {str(e)[:80]}")
                        self._log(f"   ❌ Lỗi: {str(e)[:100]}")

                    self.result_store.add(record)
                    # Nghỉ ngẫu nhiên giữa các từ khóa để không bị nghi ngờ
                    human_sleep(8, 20)

                browser.close()
                self._write_progress("done", f"Hoàn thành {self.processed} từ khóa")
                self._log(f"🏁 Kết thúc. Đã tra {self.processed} từ khóa, thấy {self.found_count} lượt hwood.vn")
        except Exception as e:
            self._write_progress("error", str(e)[:100])
            self._log(f"💥 Lỗi trình duyệt: {e}")


# ==============================================================================
# 5. HÀM CHẠY TOÀN BỘ 5 BOT (DÙNG CHO CLI VÀ STREAMLIT)
# ==============================================================================
def chay_5_bot(
    danh_sach_tu_khoa: List[str],
    danh_sach_bot: Optional[List[BotConfig]] = None,
    max_pages: int = 5,
    dwell_min: int = 45,
    dwell_max: int = 90,
    visit_pages: bool = True,
    headless: bool = True,
) -> Tuple[List[Dict], List[BotWorker]]:
    """
    Khởi chạy 5 bot song song. Trả về (danh_sach_ket_qua, danh_sach_thread_bot).
    Giao diện Streamlit có thể theo dõi tiến độ qua file bot_farm_progress.json.
    """
    # Xáo trộn từ khóa ngẫu nhiên, bỏ trùng lặp
    unique_kw = list(dict.fromkeys([k.strip() for k in danh_sach_tu_khoa if k and k.strip()]))
    random.shuffle(unique_kw)
    kw_queue: queue.Queue = queue.Queue()
    for kw in unique_kw:
        kw_queue.put(kw)

    if danh_sach_bot is None:
        danh_sach_bot = doc_proxy_config()

    # Xóa file tiến độ cũ
    if os.path.exists(PROGRESS_FILE):
        os.remove(PROGRESS_FILE)

    store = ResultStore()
    stop_event = threading.Event()
    bots = []
    for cfg in danh_sach_bot:
        bot = BotWorker(
            config=cfg,
            keyword_queue=kw_queue,
            result_store=store,
            max_pages=max_pages,
            dwell_min=dwell_min,
            dwell_max=dwell_max,
            visit_pages=visit_pages,
            headless=headless,
            stop_event=stop_event,
        )
        bots.append(bot)

    print("=" * 60)
    print(f"🤖 KHỞI CHẠY {len(bots)} BOT | {len(unique_kw)} TỪ KHÓA | Quét tới trang {max_pages}")
    print("=" * 60)
    for b in bots:
        b.start()
        human_sleep(0.5, 1.5)  # Khởi động lệch pha, không mở 5 cửa sổ cùng lúc

    return store.all(), bots


def doc_tien_do() -> Dict:
    """Đọc tiến độ các bot từ file (dùng cho Streamlit hiển thị)."""
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def doc_ket_qua() -> List[Dict]:
    if os.path.exists(RESULTS_FILE):
        try:
            with open(RESULTS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []
