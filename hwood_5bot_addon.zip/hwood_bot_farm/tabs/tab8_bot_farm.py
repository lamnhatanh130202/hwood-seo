# -*- coding: utf-8 -*-
"""
TAB 8 - HỆ THỐNG 5 BOT QUÉT THỨ HẠNG GOOGLE (PROXY/VPN RIÊNG)
File này là MỚI, không đụng vào các tab cũ. Để thêm vào app.py, xem hướng dẫn
cuối file hoặc file README_5_BOT.md.
"""
import os
import sys
import json
import csv
import io
import signal
import subprocess
import streamlit as st
from datetime import datetime

# Thư mục gốc dự án (chứa app.py) - file này nằm trong tabs/
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Tái dùng bộ từ khóa mẫu có sẵn của dự án (nếu có)
try:
    from modules.rank_tracker import BO_TU_KHOA_HWOOD_PRESETS
    HAS_PRESETS = True
except Exception:
    BO_TU_KHOA_HWOOD_PRESETS = {}
    HAS_PRESETS = False

from modules.bot_farm import doc_tien_do, doc_ket_qua

# Lưu tiến trình subprocess đang chạy (module-level, tồn tại qua các lần rerun)
RUNNING_PROC = {"popen": None, "started_at": None}


# ==============================================================================
# TIỆN ÍCH GHI CẤU HÌNH RA FILE
# ==============================================================================
def ghi_file(path: str, content: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def ghi_cau_hinh(keywords_text: str, proxies: list, settings: dict):
    # 1. Từ khóa
    ghi_file(os.path.join(BASE_DIR, "bot_keywords.txt"), keywords_text)
    # 2. Proxy
    ghi_file(
        os.path.join(BASE_DIR, "bot_proxies.json"),
        json.dumps({"bots": proxies}, ensure_ascii=False, indent=2),
    )
    # 3. Cài đặt
    ghi_file(
        os.path.join(BASE_DIR, "bot_settings.json"),
        json.dumps(settings, ensure_ascii=False, indent=2),
    )


def dang_chay() -> bool:
    p = RUNNING_PROC.get("popen")
    return p is not None and p.poll() is None


def dung_bot():
    p = RUNNING_PROC.get("popen")
    if p and p.poll() is None:
        try:
            p.terminate()
            try:
                p.wait(timeout=5)
            except Exception:
                p.kill()
        except Exception:
            pass
    RUNNING_PROC["popen"] = None


# ==============================================================================
# HÀM RENDER TAB (gọi từ app.py)
# ==============================================================================
def render_tab8():
    st.markdown("### 🤖 Hệ Thống 5 Bot Quét Thứ Hạng Google (Proxy/VPN Riêng)")
    st.caption(
        "5 bot chạy độc lập, mỗi bot 1 IP riêng, chia sẻ chung danh sách từ khóa "
        "(lấy ngẫu nhiên đến khi hết). Quét trang 1→5, ghi nhận thứ hạng bài/sản phẩm "
        "hwood.vn, nếu thấy thì vào trang đọc nội dung và ở lại tự nhiên như người thật."
    )

    # ---------- CỘT TRÁI: CẤU HÌNH | CỘT PHẢI: TIẾN ĐỘ + KẾT QUẢ ----------
    col_cfg, col_run = st.columns([1, 1.4])

    with col_cfg:
        st.markdown("#### 1️⃣ Danh sách từ khóa (5 bot dùng chung)")
        preset_choice = "Nhập tay"
        if HAS_PRESETS:
            preset_choice = st.selectbox(
                "Chọn bộ từ khóa mẫu:",
                options=["Nhập tay"] + list(BO_TU_KHOA_HWOOD_PRESETS.keys()),
                help="Chọn bộ mẫu để tự động nạp vào ô bên dưới, rồi bạn có thể sửa thêm.",
            )
        default_kw = ""
        if preset_choice != "Nhập tay" and HAS_PRESETS:
            default_kw = "\n".join(BO_TU_KHOA_HWOOD_PRESETS.get(preset_choice, []))
        keywords_text = st.text_area(
            "Mỗi dòng 1 từ khóa:",
            value=default_kw,
            height=160,
            placeholder="gỗ nhựa ngoài trời\ntấm nhựa ốp tường\ntrần nano\n...",
        )

        st.markdown("#### 2️⃣ Cấu hình 5 Proxy/VPN (mỗi bot 1 IP riêng)")
        st.caption(
            "Để trống proxy_server thì bot đó dùng IP máy tính. "
            "Định dạng: http://user:pass@ip:port hoặc socks5://ip:port. "
            "Xem README để biết cách lấy proxy từ tài khoản VPN (NordVPN/Surfshark...)."
        )
        proxies = []
        for i in range(5):
            with st.expander(f"🤖 Bot {i+1} — Cấu hình IP", expanded=(i == 0)):
                c1, c2 = st.columns(2)
                with c1:
                    name = st.text_input(f"Tên bot {i+1}:", value=f"Bot {i+1}", key=f"botname_{i}")
                    server = st.text_input(
                        f"Proxy server {i+1}:",
                        value="",
                        placeholder="http://1.2.3.4:8080",
                        key=f"proxy_{i}",
                        help="Để trống = dùng IP máy tính."
                    )
                with c2:
                    user = st.text_input(f"Username proxy {i+1}:", value="", key=f"puser_{i}")
                    pwd = st.text_input(f"Password proxy {i+1}:", value="", type="password", key=f"ppass_{i}")
                proxies.append({
                    "bot_id": f"bot_{i+1:02d}",
                    "name": name,
                    "proxy_server": server.strip(),
                    "proxy_username": user.strip(),
                    "proxy_password": pwd.strip(),
                })

        st.markdown("#### 3️⃣ Cài đặt hoạt động")
        c1, c2 = st.columns(2)
        with c1:
            max_pages = st.slider("Quét tới trang Google:", 1, 5, 5)
            dwell_min = st.number_input("Thời gian đọc trang tối thiểu (giây):", 5, 300, 45)
        with c2:
            dwell_max = st.number_input("Thời gian đọc trang tối đa (giây):", 5, 600, 90)
            visit_pages = st.checkbox("Vào trang hwood.vn đọc nội dung khi thấy", value=True)
            headless = st.checkbox("Chạy ẩn (không hiện cửa sổ trình duyệt)", value=True)

        settings = {
            "max_pages": int(max_pages),
            "dwell_min": int(dwell_min),
            "dwell_max": int(dwell_max),
            "visit_pages": bool(visit_pages),
            "headless": bool(headless),
        }

        st.markdown("---")
        if not dang_chay():
            if st.button("🚀 Bắt đầu chạy 5 Bot", type="primary", use_container_width=True):
                if not keywords_text.strip():
                    st.error("❌ Chưa có từ khóa! Hãy nhập ít nhất 1 từ khóa.")
                else:
                    ghi_cau_hinh(keywords_text, proxies, settings)
                    runner = os.path.join(BASE_DIR, "run_bot_farm.py")
                    try:
                        proc = subprocess.Popen(
                            [sys.executable, runner],
                            cwd=BASE_DIR,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                        )
                        RUNNING_PROC["popen"] = proc
                        RUNNING_PROC["started_at"] = datetime.now().strftime("%H:%M:%S")
                        st.success(f"✅ Đã khởi động 5 bot lúc {RUNNING_PROC['started_at']}!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Lỗi khởi động: {e}")
        else:
            st.warning(f"⏳ 5 bot đang chạy (bắt đầu lúc {RUNNING_PROC.get('started_at')})...")
            if st.button("⏹️ Dừng tất cả bot", use_container_width=True):
                dung_bot()
                st.success("Đã gửi lệnh dừng.")
                st.rerun()

    with col_run:
        st.markdown("#### 📊 Tiến độ từng bot")
        if st.button("🔄 Làm mới tiến độ & kết quả", use_container_width=True):
            st.rerun()

        prog = doc_tien_do()
        if prog:
            for bot_id, info in prog.items():
                status_icon = {
                    "running": "🔍", "done": "✅", "blocked": "⛔",
                    "error": "❌", "starting": "⚙️",
                }.get(info.get("status", ""), "⚪")
                with st.container(border=True):
                    st.markdown(
                        f"{status_icon} **{info.get('name', bot_id)}** — "
                        f"`{info.get('status', '')}` | "
                        f"Đã tra: **{info.get('processed', 0)}** từ khóa | "
                        f"Thấy hwood: **{info.get('found', 0)}** lượt"
                    )
                    if info.get("detail"):
                        st.caption(f"👉 {info['detail']}")
        else:
            st.info("Chưa có tiến độ. Nhấn 'Bắt đầu chạy 5 Bot' để khởi động.")

        st.markdown("#### 📋 Kết quả đã ghi nhận")
        results = doc_ket_qua()
        if results:
            # Chuẩn bị bảng hiển thị
            rows = []
            for r in results[-50:]:  # Hiển thị 50 kết quả gần nhất
                hits = r.get("ket_qua_hwood", [])
                if hits:
                    rank_str = ", ".join([f"Top {h['position']} (trang{h.get('trang_google','?')})" for h in hits[:3]])
                    urls = "; ".join([h["url"].replace("https://", "")[:50] for h in hits[:2]])
                else:
                    rank_str = "⚪ Ngoài Top 50"
                    urls = "-"
                rows.append({
                    "Từ khóa": r.get("tu_khoa", ""),
                    "Bot": r.get("bot_name", ""),
                    "Thứ hạng hwood.vn": rank_str,
                    "URL": urls,
                    "Trạng thái": r.get("trang_thai", ""),
                    "Thời gian": r.get("thoi_gian", ""),
                })
            st.dataframe(rows, use_container_width=True, hide_index=True)

            # Xuất CSV
            csv_buf = io.StringIO()
            writer = csv.writer(csv_buf)
            writer.writerow(["tu_khoa", "bot", "thoi_gian", "trang_thai", "vi_tri", "url", "tieu_de"])
            for r in results:
                hits = r.get("ket_qua_hwood", [])
                if hits:
                    for h in hits:
                        writer.writerow([
                            r.get("tu_khoa", ""), r.get("bot_name", ""), r.get("thoi_gian", ""),
                            "found", h.get("position", ""), h.get("url", ""), h.get("title", ""),
                        ])
                else:
                    writer.writerow([
                        r.get("tu_khoa", ""), r.get("bot_name", ""), r.get("thoi_gian", ""),
                        r.get("trang_thai", "not_found"), "", "", "",
                    ])
            st.download_button(
                "⬇️ Tải kết quả CSV",
                data=csv_buf.getvalue().encode("utf-8-sig"),
                file_name=f"ket_qua_5bot_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                mime="text/csv",
            )
        else:
            st.info("Chưa có kết quả nào. Kết quả sẽ hiện ở đây khi bot bắt đầu tra từ khóa.")

    st.markdown("---")
    st.caption(
        "⚠️ Lưu ý: Công cụ này dùng để KIỂM TRA THỨ HẠNG và XÁC MINH NỘI DUNG. "
        "Việc click + ở lại trang ở quy mô lớn có thể bị Google xem là thao túng CTR "
        "và gây rủi ro cho website. Nên dùng proxy residential (IP nhà dân) và chạy vừa phải."
    )


# ==============================================================================
# HƯỚNG DẪN THÊM TAB NÀY VÀO app.py (CHỈ THÊM, KHÔNG SỬA FILE CŨ)
# ==============================================================================
# Trong file app.py của bạn, thêm 3 dòng sau:
#
#   1. Ở phần import tab (gần các dòng 'from tabs.tab7_... import ...'), thêm:
#        from tabs.tab8_bot_farm import render_tab8
#
#   2. Trong hàm st.tabs([...]), thêm tên tab mới vào CUỐI DANH SÁCH:
#        "🤖 5 Bot Quét Thứ Hạng"
#
#   3. Thêm khối with tab_moi: render_tab8()
#
# Xem file README_5_BOT.md để biết chi tiết + cài đặt Playwright + proxy.
