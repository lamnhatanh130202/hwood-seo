---
name: graphify
description: Analyzes the codebase using AST parsing to build and query an ultra-efficient Knowledge Graph (graph.json, GRAPH_REPORT.md, graph.html). Reduces token consumption by up to 70x by mapping dependencies, functions, classes, and module relationships instead of re-reading raw files repeatedly.
---

# 🧭 Graphify: Codebase Knowledge Graph Skill for Antigravity

Kỹ năng này cho phép Antigravity tự động trích xuất, phân tích và tra cứu **Đồ thị tri thức (Knowledge Graph)** của toàn bộ dự án mà không cần phải đọc lại từng file mã nguồn nhiều lần, giúp:
1. **Tiết kiệm đến 70 lần Token** trên mỗi lượt trao đổi (Turn).
2. **Hiểu rõ điểm ảnh hưởng (Blast Radius)**: Biết ngay khi sửa hàm A thì những hàm nào, file nào bị ảnh hưởng.
3. **Cung cấp bản đồ trực quan (`graph.html`)** để người dùng mở trực tiếp trên trình duyệt Chrome.

---

## 📌 Các tệp kết quả trong `graphify-out/`

Sau khi chạy lệnh Graphify, hệ thống tự động sinh ra thư mục `graphify-out/` gồm:
- **`graph.json`**: Dữ liệu đồ thị đầy đủ gồm danh sách các node (files, functions, classes) và edges (imports, calls, defines). Antigravity có thể đọc file này để định vị nhanh bất kỳ biểu tượng nào.
- **`GRAPH_REPORT.md`**: Bản tóm tắt kiến trúc toàn dự án, danh mục tất cả các file, số dòng, danh sách hàm, tham số và liên kết gọi nhau.
- **`graph.html`**: Giao diện mạng lưới tương tác (Interactive Network Graph), có thể phóng to, thu nhỏ, kéo thả và bấm vào từng node để xem chi tiết.

---

## 🚀 Cách kích hoạt và sử dụng

### 1. Khi người dùng yêu cầu:
- *"Tạo đồ thị code"* / *"Chạy graphify"* / *"Cập nhật kiến trúc codebase"*
- Hoặc khi bắt đầu một tác vụ lớn cần khảo sát toàn bộ dự án:

**Thực thi lệnh:**
```powershell
python scripts/graphify_engine.py
```
*(Hoặc người dùng có thể nhấp đúp vào file `TAO_DO_THI_CODE.bat` ở thư mục gốc dự án)*

### 2. Quy trình làm việc của Antigravity (Agent Workflow):
- **Bước 1 (Tra cứu bản đồ trước)**: Thay vì dùng `read_file` đọc hàng loạt file mã nguồn để tìm một hàm hoặc xem luồng hoạt động, Antigravity đọc file `graphify-out/GRAPH_REPORT.md` hoặc `graphify-out/graph.json`.
- **Bước 2 (Xác định mục tiêu chính xác)**: Dựa vào đồ thị để biết chính xác file và số dòng cần chỉnh sửa.
- **Bước 3 (Chỉ đọc & sửa đúng file cần thiết)**: Dùng `read_file` hoặc `edit_file` ngay tại vị trí xác định, tiết kiệm tối đa token cho phiên làm việc.
